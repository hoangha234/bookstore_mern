export const PORT = 5555;
export const MONGO_URL = 'mongodb://rdp.isharoverwhite.cloud:12818/Books-Store-MERN';